package com.springcore.Ci;

public class Persion {
	private String name;
	private int personId;
	private Cirti certi;
	
	public Persion(String name, int personId,Cirti certi) {
		this.name=name;
		this.personId=personId;
		this.certi=certi;
		
	}

	@Override
	public String toString() {
		return this.name+ " : "+ this.personId+"{"+this.certi.name+"}" ;
	}
	

}
