package com.springcore.Ci;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context=new ClassPathXmlApplicationContext("com/springcore/Ci/configCI.xml");
		
		Persion p1 =(Persion) context.getBean("P1");
		System.out.println(p1);

	}

}
