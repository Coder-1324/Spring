package com.springcore.Ci;

public class Cirti {
	 String name ;

	public Cirti(String name) {
		super();
		this.name = name;
	}

	@Override
	public String toString() {
		return this.name;
	}
	
	

}
