package com.springcore.collection;

import java.util.List;
import java.util.Map;
import java.util.Set;

public class Emp {

	private String name;
	private List<String> phone;
	private Set<String> addresses;
	private Map<String, String> courrses;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<String> getPhone() {
		return phone;
	}
	public void setPhone(List<String> phone) {
		this.phone = phone;
	}
	public Set<String> getAddresses() {
		return addresses;
	}
	public void setAddresses(Set<String> addresses) {
		this.addresses = addresses;
	}
	public Map<String, String> getCourrses() {
		return courrses;
	}
	public void setCourrses(Map<String, String> courrses) {
		this.courrses = courrses;
	}
	public Emp(String name, List<String> phone, Set<String> addresses, Map<String, String> courrses) {
		super();
		this.name = name;
		this.phone = phone;
		this.addresses = addresses;
		this.courrses = courrses;
	}
	public Emp() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
