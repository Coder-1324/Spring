package com.springcore.ref;

public class b {

	private int y;

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public b(int y) {
		super();
		this.y = y;
	}

	public b() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "b [y=" + y + "]";
	}
	
	
}
