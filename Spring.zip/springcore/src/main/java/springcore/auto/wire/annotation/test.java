package springcore.auto.wire.annotation;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.springcore.collection.Emp;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		ApplicationContext context =new ClassPathXmlApplicationContext("springcore/auto/wire/auto.config.xml");
		Emp emp1= context.getBean("emp1",Emp.class);
		
		System.out.println("emp1");

	}

}
